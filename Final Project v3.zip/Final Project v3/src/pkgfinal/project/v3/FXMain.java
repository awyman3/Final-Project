//Aidan Wyman
//Final Project Version 3.0
//final.project.v3.java
//10/16/2022
//This program prompts the user with a menu to either enter a new log for a song, or to terminate the program.
//  If the user choses to enter a new log, they're prompted with text boxes to fill out information regarding
//  said song. Once the user lists the information needed, they will hit the save button, which displays the song information, 
//  while bringing the user back to the first menu to start the process over again.

package pkgfinal.project.v3;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.layout.VBox;

public class FXMain extends Application 
{
    Stage window;
    Scene scene1, scene2;
    int counter;
    
    public static void main(String[] args) 
    {
        launch(args);
    }
    
    @Override
    public void start(Stage primaryStage) throws Exception
    {
        window = primaryStage;
        
//========================btn1=======================================
        Label label1 = new Label("Choose an Option!");
        Button btn1 = new Button("Enter new log: ");
        btn1.setOnAction(new EventHandler<ActionEvent>() 
        {
            @Override
            public void handle(ActionEvent event) 
            {
                int ID[];
                String artistName = "";
                String songTitle = "";
                String genre = "";
                String numericalRating = "";
                String description = "";
                
                
                counter++;
                window.setScene(scene2);
                System.out.println("Song number " + counter + ": ");
            }
        });
        
        
//===========================btn2(quit)=====================================
        Button btn2 = new Button("Quit");
        btn2.setOnAction((ActionEvent event) -> 
        {
            Platform.exit();
        });
        
//=========================scene1=======================================
        VBox layout1 = new VBox(20);
        layout1.getChildren().addAll(label1, btn1, btn2);
        scene1 = new Scene(layout1, 600, 400);
        
//============================btn3(quit)===================================
        Button btn3 = new Button("Quit");
        btn3.setOnAction((ActionEvent event) -> 
        {
            Platform.exit();
        });
       
//text fields       
        TextField textField1 = new TextField("");
        TextField textField2 = new TextField("");
        TextField textField3 = new TextField("");
        TextField textField4 = new TextField("");
        TextField textField5 = new TextField("");
        
        Label label2 = new Label("Artist Name: ");
        Label label3 = new Label("Song Name: ");
        Label label4 = new Label("Genre: ");
        Label label5 = new Label("Numerical Rating (out of 10): ");
        Label label6 = new Label("Description: ");
       
        HBox box = new HBox(5);
        box.setPadding(new Insets(5, 5 , 5, 5));
        
//Retrieving data from text fields
        Button btnSave = new Button ("Save");
        btnSave.setOnAction(e -> 
        {
            String artistName = textField1.getText();
            String songTitle = textField2.getText();
            String genre = textField3.getText();
            String numericalRating = textField4.getText();
            String description = textField5.getText();
            System.out.println(artistName + "\n" + songTitle + "\n" + genre + "\n" + numericalRating + "\n" + description);

            textField1.clear();
            textField2.clear();
            textField3.clear();
            textField4.clear();
            textField5.clear();

            window.setScene(scene1);
        });
        
//==========================scene2=========================================
        VBox layout2 = new VBox(5);
        layout2.getChildren().addAll(btn3, label2, textField1, label3, textField2, label4, textField3, label5, textField4, label6, textField5, btnSave);
        scene2 = new Scene(layout2, 600, 600);
//===========================window==================================
        window.setScene(scene1);
        window.setTitle("===== Final Project: Song Log ===== ");
        window.show();
    }
// end
    

    
    
    
}
